#include "SyntaxAnalyzer.h"
#include "lex.h"
#include "record.h"
#include "Logger.h"

SyntaxAnalyzer::SyntaxAnalyzer()
{
}
SyntaxAnalyzer::~SyntaxAnalyzer()
{
}
/* Parse the syntax for every lexeme in the lexer. */     
void SyntaxAnalyzer::Parse(Lexer * lex)
{
    lexer = lex;
    Rat11f();
}

void SyntaxAnalyzer::PrintResults(string filelocation)
{
    this->logger.WriteToLogFile(filelocation);
}
/* Sets the internal record variable to the next record produced by the lexer. */
void SyntaxAnalyzer::NextRecord()
{
    this->rrr = lexer->Lex();
}
/* <Rat11F> ::= # <Opt Function Definitions>
                # <Opt Declaration List> <Statement List> # */
void SyntaxAnalyzer::Rat11f()
{
	NextRecord();
    if(rrr == s_pound)
    {        
        OptFunctionDefinitions();
        // will return with next next record as a #
        if(rrr == s_pound)
        {
            OptDeclarationList();
            StatementList();
            if(rrr == s_pound)
            {
                logger.Log("<Rat11F> ::= # <Opt Function Definitions># <Opt Declaration List> <Statement List> #");
            }
			else
			{
				// log error
				logger.Log("Error: Expecting '#' Try again and come back later. Gracias!");
			}
        }
		else
		{
			// log error
			logger.Log("Error: Expecting '#' Try again and come back later. Thank you!");
		}
    }
    else
    {
		// log error
		logger.Log("Error: Expecting '#' Try again and come back later. Gracias!");
    }
}
/* <Opt Function Definitions> ::= <Function Definitions> | <Empty> */
void SyntaxAnalyzer::OptFunctionDefinitions()
{
    NextRecord();
    if(rrr == k_function)
    {        
		FunctionDefinitions();
        logger.Log(" <Opt Function Definitions> ::= <Function Definitions>");
    }
    else //if(Empty())
    {
        // log empty
		logger.Log("<Opt Function Definitions> ::= <Empty>");
    }
}
/* <Function Definitions> ::= <Function> <Function Definitions Prime> */
void SyntaxAnalyzer::FunctionDefinitions()
{
	Function();
	FunctionDefinitionsPrime();
    logger.Log("<Function Definitions> ::= <Function> <Function Definitions Prime>");
}
/* <Function Definitions Prime> :: <Function Definitions> | <Empty> */
void SyntaxAnalyzer::FunctionDefinitionsPrime()
{
    NextRecord();
    if(rrr == k_function)
    {       
	   FunctionDefinitions();
       logger.Log("<Opt Function Definitions Prime> ::= <Function Definitions>");
    }
    else // empty
    {
        // log empty
		logger.Log("<Opt Function Definitions> ::= <Empty>");
    }
}
/* <Function> ::= function <Identifier> ( <Opt Parameter List> ) <Opt Declaration List> <Body> */
void SyntaxAnalyzer::Function()
{
    if(rrr == k_function)
    {
        NextRecord();
        if(rrr == Identifier)
        {
            NextRecord();
            if(rrr == s_openbracketround)
            {
                OptParameterList();
                NextRecord();
                if(rrr == s_closebracketround)
                {					
                    OptDeclarationList();
                    Body();
                    logger.Log("<Function> ::= function <Identifier> ( <Opt Parameter List> ) <Opt Declaration List> <Body>");
                }
                else
                {
                    // error
					logger.Log("Error: Expecting ')' Try again and come back later. Gracias!");
                }
            }
            else
            {
                // error
				logger.Log("Error: Expecting '(' Try again and come back later. Gracias!");
            }
        }
        else
        {
            // error
			logger.Log("Error: Expecting Identifier. Try again and come back later. Thank you!");
        }
    }
    else
    {
        // error
		logger.Log("Error: Expecting Function Try again and come back later. Gracias!");
    }
}
/* <Opt Parameter List> ::= <Parameter List> | <Empty> */
void SyntaxAnalyzer::OptParameterList()
{
    paramList = false;
	if(ParameterList())
    {
		logger.Log("<Opt Parameter List> ::= <Parameter List>");
    }
	else // if(Empty())
    {
		logger.Log("<Opt Parameter List> ::= <Empty>");
    }
}
/* <Parameter List> ::= <Parameter> <Parameter List Prime> */
bool SyntaxAnalyzer::ParameterList()
{    
	if(Parameter())
    {
	    ParameterListPrime();
    }
    else
    {
        return paramList;
		//logger.Log("Error: Check syntax");
    }
}
/* <Parameter List Prime> ::= , <Parameter List> | <Empty> */
void SyntaxAnalyzer::ParameterListPrime()
{
    if(rrr == s_comma)
    {
		logger.Log("<Parameter List Prime> ::= , <Parameter List>");
        paramList = false;
		ParameterList();
    }
    else // if(Empty())
    {
		logger.Log("<Parameter List Prime> ::= <Empty>");
    }
}
/* <Parameter> ::= <IDs> : <Qualifier> */
bool SyntaxAnalyzer::Parameter()
{
	if(IDs())
    {
        NextRecord();
        if(rrr == s_colon)
        {
	        if(Qualifier())
            {                
				logger.Log("<Parameter> ::= <IDs> : <Qualifier>");
                return true;
            }
            else
            {
               logger.Log("Error: Expecting 'int | boolean | real' Try again and come back later. Gracias!");
                return true;
            }            
        }
        else
        {
            // error
            return true;
        }
    }
    else
    {
        // no error
        return false;
    }
}
/* <Qualifier> ::= int | boolean | real */
bool SyntaxAnalyzer::Qualifier()
{
    NextRecord();
	if(rrr == k_int)
	{
		// log
		logger.Log("<Qualifier> ::= int");
        return true;
	}
	else if(rrr == k_boolean)
	{
		// log        
		logger.Log("<Qualifier> ::= boolean");
        return true;
	}
	else if(rrr == k_real)
	{
        // log
		logger.Log("<Qualifier> ::= real");
        return true;
	}
	else{
        return false;
		//
	}
}
/* <Body> ::= { <Statement List> } */
void SyntaxAnalyzer::Body()
{
    NextRecord();
    if(rrr == s_openbracketcurly)
    {
        StatementList();
        NextRecord();
        if(rrr == s_closebracketcurly)
        {
            // log
			logger.Log("<Body> ::= { <Statement List> }");
        }
        else
        {
            // error
			logger.Log("Error: expecting '}' try that and come again later, Thank you. ");
        }
    }
}
/* <Opt Declaration List> ::= <Declaration List> | <Empty> */
void SyntaxAnalyzer::OptDeclarationList()
{
	if(DeclarationList())
    {
        logger.Log("<Opt Declaration List> ::= <Declaration List>");
    }
	else // if(Empty())
    {
        logger.Log("<Opt Declaration List> ::= <Empty>");
    }
}
/* <Declaration List> ::= <Declaration> ; <Declaration List Prime> */
bool SyntaxAnalyzer::DeclarationList()
{
	if(Declaration())
    {
        NextRecord();
        if(rrr == s_semicolon)
        {
		
	        DeclarationListPrime();
            logger.Log("<Declaration List> ::= <Declaration> ; <Declaration List Prime>");
            return true;
        }
        else
        {
            // error
		    logger.Log("Error: Expecting ';' Try that and come again later. Thank you");
            // or not declaration list
            return true;
        }
	}
    else
    {
        return false;
    }
}
/* <Declaration List Prime> ::= <Declaration List> | <Empty> */
void SyntaxAnalyzer::DeclarationListPrime()
{
	if(DeclarationList())
    {
        // log
		logger.Log("<Declaration List Prime> ::= <Declaration List>");
    }
	else // if(Empty())
    {
        // log
		logger.Log("<Declaration List Prime> ::= <Empty>");
    }
}
/* <Declaration> ::= <Qualifier> <IDs> */
bool SyntaxAnalyzer::Declaration()
{
	if(Qualifier())
	{ 
        if(IDs())
        {
            // log
            logger.Log("<Declaration> ::= <Qualifier> <IDs>");
            return true;
        }
        else
        {
            // error
            return true;
        }
    }
    else
    {
        return false;
    }
}
/* <IDs> ::= <Identifier> <IDs Prime> */
bool SyntaxAnalyzer::IDs()
{
    NextRecord();
    if(rrr == Identifier)
    {		
        IDsPrime();
        // log
        logger.Log("<IDs> ::= <Identifier> <IDs Prime>");
        return true;
    }
    else
    {
        return false;
    }
}
/* <IDs Prime> ::= , <IDs> | <Empty> */
void SyntaxAnalyzer::IDsPrime()
{
    NextRecord();
    if(rrr == s_comma)
    {
		logger.Log("<IDs Prime> ::= , <IDs>");
	    IDs();
        // log
    }
    else
    {
		logger.Log("<IDs Prime> ::= <Empty>");
    }
}
/* <Statement List> ::= <Statement> <Statement List Prime> */
bool SyntaxAnalyzer::StatementList()
{
	logger.Log("<Statement List> ::= <Statement> <Statement List Prime>");
	Statement();
	StatementListPrime();
    return true;
}
/* <Statement List Prime> ::= <Stamement List> | <Empty> */
void SyntaxAnalyzer::StatementListPrime()
{
	if(StatementList())
    {
		logger.Log("<Statement List Prime> ::= <Stamement List>");
    }
	else //if(Empty())
    {
		logger.Log("<Statement List Prime> ::= <Empty>");
    }    
}
/* <Statement> ::= <Compound> | <Assign> | <If> | <Return> | <Write> | <Read> | <While> */
void SyntaxAnalyzer::Statement()
{
    NextRecord();
	if(Compound())
    {
        // log
		logger.Log("<Statement> ::= <Compund>");
    }
	else if(Assign())
    {
        logger.Log("<Statement> ::= <Assign>");
    }
	else if(If())
    {
        // log
		logger.Log("<Statement> ::= <If>");
    }
	else if(Return())
    {
        // log
		logger.Log("<Statement> ::= <Return>");
    }
	else if(Write())
    {
        // log
		logger.Log("<Statement> ::= <Write>");
    }
	else if(Read())
    {
        // log
		logger.Log("<Statement> ::= <Read>");
    }
	else if(While())
    {
        // log
		logger.Log("<Statement> ::= <While>");
    }
    else
    {
        // error
		logger.Log("Error: Expecting '<Compound> | <Assign> | <If> | <Return> | <Write> | <Read> | <While>' Try again and come back later. Gracias!");
    }
}
/* <Compound> ::= { <Statement List> } */
bool SyntaxAnalyzer::Compound()
{ 
	if(rrr == s_openbracketcurly)
	{
        StatementList();
		NextRecord();
        if(rrr == s_closebracketcurly)
        {
			logger.Log("<Compound> ::= { <Statement List> }");
			return true;
        }
        else
        {
			logger.Log("Error: Expecting '{' Try again and come back later. Gracias!");
            return false;
        }
	}
    else
    {
        // could be something else
		logger.Log("Error: Expecting '}' Try again and come back later. Gracias!");
	    return false;
    }
}
/* <Assign> ::= <Identifier> := <Expression> ; */
bool SyntaxAnalyzer::Assign()
{
	if(rrr == Identifier)
	{
        NextRecord();
        if(rrr == o_equal)
        {
            Expression();
            logger.Log("Assign ::= <Identifier> := <Expression>");
        }
        else
        {
            // error
			logger.Log("Error: Expecting '=' Try again and come back later. Gracias!");
        }
	}
    return false;
}
/* <If> ::= if ( <Condition> ) <Statement> <If Prime> */
bool SyntaxAnalyzer::If()
{
    if(rrr == k_if)
    {
        NextRecord();
        if(rrr == s_openbracketround)
        {
            Condition();
            NextRecord();
            if(rrr == s_closebracketround)
            {
				Statement();
                IfPrime();
                // log
                logger.Log("<If> ::= if ( <Condition> ) <Statement> <If Prime>");
            }
            else
            {
                // error
				logger.Log("Error: Expecting ')' Try again and come back later. Gracias!");
            }
        }
        else
        {
            // error
			logger.Log("Error: Expecting '(' Try again and come back later. Gracias!");
        }
    }
    return false;
}
/* <If Prime> ::= endif | else <Statement> endif */
void SyntaxAnalyzer::IfPrime()
{
    NextRecord();
    if(rrr == k_endif)
    {
        // log
    }
    else if(rrr == k_else)
    {
        Statement();
        NextRecord();
        if(rrr == k_endif)
        {
            // log
			logger.Log("<If Prime> ::= endif | else <Statement> endif");
        }
        else
        {
            // error
			logger.Log("Error: Expecting keword 'endif' Try again and come back later. Gracias!");
        }
    }
    else
    {
        // error
		logger.Log("Error: Expecting keword 'else' Try again and come back later. Gracias!");
    }
}
/* <Return> ::=  return <Return Prime> */
bool SyntaxAnalyzer::Return()
{
    if(rrr == k_return)
    {		
		ReturnPrime();
        logger.Log("<Return> ::=  return <Return Prime>");
        return true;
    }
    return false;
}
/* <Return Prime> ::= <Expression> ; | ; <Empty> */
void SyntaxAnalyzer::ReturnPrime()
{
    NextRecord();
    if(rrr == s_semicolon)
    {
        logger.Log("<Return Prime> ::= ; epsilon");
    }
    else
    {
		Expression();
        if(rrr == s_semicolon)
        {
            // log
            logger.Log("<Return Prime> ::= <Expression> ;");
        }
        else
        {
            // error
			logger.Log("Error: Syntax FAIL");
        }
    }
}
/* <Write> ::= print ( <Expression> ); */
bool SyntaxAnalyzer::Write()
{
    NextRecord();
    if(rrr == k_print)
    {
        NextRecord();
        if(rrr == s_openbracketround)
        {
            Expression();
            if(rrr == s_closebracketround)
            {
                NextRecord();
                if(rrr == s_semicolon)
                {
					logger.Log("<Write> ::= print ( <Expression> );");
                    
                    return true;
                }
                else
                {
                    // error
					logger.Log("Error: Expecting separator ';' Try again and come back later. Gracias!");
                    return true;
                }
            }
            else
            {
                // error
				logger.Log("Error: Expecting separator '(' Try again and come back later. Gracias!");
                return true;
            }
        }
        else
        {
            // error
			logger.Log("Error: Expecting separator '(' Try again and come back later. Gracias!");
            return true;
        }
    }
    else
    {
        logger.Log("Error: Expecting function 'print' Try again and come back later. Gracias!");
		return false;
    }
}
/* <Read> ::= scan ( <IDs> ); */
bool SyntaxAnalyzer::Read()
{
    NextRecord();
    if(rrr == k_scan)
    {
        NextRecord();
        if(rrr == s_openbracketround)
        {
            IDs();
            NextRecord();
            if(rrr == s_closebracketround)
            {
                NextRecord();
                if(rrr == s_semicolon)
                {
                    // log
					logger.Log("<Read> ::= scan ( <IDs> );");
                    return true;
                }
                else
                {
                    // error
					logger.Log("Error: Expecting separator ';' Try again and come back later. Gracias!");
                    return true;
                }
            }
            else
            {
                // error
				logger.Log("Error: Expecting separator '(' Try again and come back later. Gracias!");
                return true;
            }
        }
        else
        {
            // error
			logger.Log("Error: Expecting separator ')' Try again and come back later. Gracias!");
            return true;
        }
    }
    else
    {
        return false;
    }
}

/* <While> ::= while ( <Condition> ) <Statement> */
bool SyntaxAnalyzer::While()
{
    NextRecord();
    if(rrr == k_while)
    {
        NextRecord();
        if(rrr == s_openbracketround)
        {
            Condition();
            if(rrr == s_closebracketround)
            {
				
                Statement();
                // log
				logger.Log("While> ::= while ( <Condition> ) <Statement>");
                return true;
            }
            else
            {
                // error
				logger.Log("Error: Expecting separator ')' Try again and come back later. Gracias!");
                return true;
            }
        }
        else
        {
            // error
			logger.Log("Error: Expecting separator '(' Try again and come back later. Gracias!");
            return true;
        }
    }
    else
    {
        return false;
    } 
}

/* <Condition> ::= <Expression> <Relop> <Expression> */
void SyntaxAnalyzer::Condition()
{
    Expression();
    Relop();
    Expression();
    logger.Log("<Condition> ::= <Expression> <Relop> <Expression>");
}

/* <Relop> ::= = | /= | > | < | => | <= */
void SyntaxAnalyzer::Relop()
{
    NextRecord();
    if(rrr == o_equalequal)
    {
        // log
		logger.Log("<Relop> ::= =");
    }
    else if(rrr == o_notequal)
    {
        // log
		logger.Log("<Relop> ::= /=");
    }
    else if(rrr == o_greatorthan)
    {
        // log
		logger.Log("<Relop> ::= >");
	}
	else if(rrr == o_lessthan)
	{
		logger.Log("<Relop> ::= <");
	}
    else if(rrr == o_greatororequal)
    {
        // log
		logger.Log("<Relop> ::= =>");
    }
    else if(rrr == o_lessorequal)
    {
        // log
		logger.Log("<Relop> ::= =<");
    }
    else
    {
        // error
		logger.Log("Error: Expecting operator '= | /= | > | < | => | <=' Try again and come back later. Gracias!");
		
	}
}
/* <Expression> ::= <Term> <Expression Prime> */
void SyntaxAnalyzer::Expression()
{
    Term();
    ExpressionPrime();
    // log
    logger.Log("<Expression ::= <Term><Expression Prime>");
}
/* <Expression Prime> ::= + <Term> <Expression Prime> | - <Term> <Expression Prime> | epsilon */
void SyntaxAnalyzer::ExpressionPrime()
{
    NextRecord();
    if(rrr == o_plus)
    {
        Term();
        ExpressionPrime();
        // log
		logger.Log("<Expression Prime> ::= + <Term> <Expression Prime>");
    }
    else if(rrr == o_minus)
    {		
		Term();
        ExpressionPrime();
        logger.Log("<Expression Prime> ::= + <Term> <Expression Prime>");        
    }
    else// if(Empty())
    {
        // log
		logger.Log(" <Expression Prime> ::= epsilon");
    }
}
/* <Term> ::= <Factor> <Term Prime> */
void SyntaxAnalyzer::Term()
{
	Factor();
	TermPrime();
    logger.Log("<Term> ::= <Factor><Term Prime>");
}
/* <Term Prime> ::= * <Factor> <Term Prime> | / <Factor> <Term Prime> | <Empty> */
void SyntaxAnalyzer::TermPrime()
{
    NextRecord();
    if(rrr == o_multiply)
    {
		logger.Log("<Term Prime> ::= * <Factor> <Term Prime>");
		Factor();
	    TermPrime();
    }
    else if(rrr == o_divide)
    {
		logger.Log("<Term Prime> ::= / <Factor> <Term Prime>");
        Factor();
        TermPrime();
    }
    else
    {
        // empty
        // log empty
		logger.Log("<Term Prime> ::= <Empty>");
        // error
		//logger.Log("Error: Expecting ' * | / ' Try again and come back later. Thank you! ");
    }
}
/* <Factor> ::= - <Primary> | <Primary> */
void SyntaxAnalyzer::Factor()
{
    NextRecord();
    if(rrr == o_minus)
    {		
	    Primary();
        logger.Log("<Factor> ::= - <Primary>");
    }
	else
    {		
        Primary();
        logger.Log("<Factor> ::= <Primary>");
    }
}
/* <Primary> ::= <Identifier> <PrimaryPrime> | <Integer> | ( <Expression> ) | <Real> | true | false */
void SyntaxAnalyzer::Primary()
{
    NextRecord();
    if(rrr == Identifier)
    {
        logger.Log("<Primary> ::= <IdentifierPrime> ");
		PrimaryPrime();
    }
    else if(rrr == Integer)
    {
        // good
		logger.Log("<Primary> ::= <Integer> ");
    }
    else if(rrr == s_openbracketround)
    {
		logger.Log("<Primary> ::= <Expression> ");
        Expression();
        NextRecord();
        if(rrr == s_closebracketround)
        {
            // log
			logger.Log("<Primary> := ( <Expression> )");
        }
        else
        {
            // error
			logger.Log("Error: Expecting separator ')' Try again and come back later. Thank you!");
        }
    }
    else if(rrr == Real)
    {
        // log
		logger.Log("<Primary> ::= <Real> ");
    }
    else if(rrr == k_true)
    {
        // log
		logger.Log("<Primary> ::= <true> ");
    }
    else if(rrr == k_false)
    {
        // log
		logger.Log("<Primary> ::= <false> ");
    }   
    else
    {
        // error
		logger.Log("Error: Expecting keyword 'real | true | false' Try again and come back later. Thank you!");
    }
}

/* <PrimaryPrime> ::= [<IDs>] | <Empty> */
void SyntaxAnalyzer::PrimaryPrime()
{
    NextRecord();
    if(rrr == s_openbracketsquare)
    {
        NextRecord();
        IDs();
        if(rrr == s_closebracketsquare)
        {
            // log
            return;
        }
        else
        {
            // error
			logger.Log("Error: Expecting separator ']' Try again and come back later. Thank you!");
        }
    }
    else
    {
        // Empty()?
        // error
		logger.Log("Error: Expecting separator '[' Try again and come back later. Thank you!");
    }
}