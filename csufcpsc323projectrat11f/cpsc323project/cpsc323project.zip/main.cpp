/*
 * Daniel Selnick
 * Angel Castrejon
 * CPSC 323 Morning Section
 * Compiler Project - Assignment 1
 */
#include "record.h"
#include "lex.h"
#include <iostream>
#include "SyntaxAnalyzer.h"
using namespace std;

// Helper function which drives the Lexical analyzer
bool RunLexer(Lexer&);

/*
 * Main
 * Arguments:
 * [0] the exe location
 * [1] the file to read
 * [2] the file to write
 * [3] if we are in silent mode
 */
int main(int argc, char **argv)
{
    // Handle arguments before creating anything
    if(argc < 3)
    {
        cout << "Requires input file, followed by output file." << endl;
        system("pause");
        return false;
    }

    // Begin driving the Lexer
    string openFileLocation = string(argv[1]);
    string writeFileLocation = string(argv[2]);

    Lexer lexer;

    lexer.OpenFileToLex(openFileLocation);

    // If the lexer completed with no errors.
    if(RunLexer(lexer))
    {        
        if(lexer.WriteRecordsToFile(writeFileLocation + "lex"))
        {
            // later assignments go here
            cout << "Records written to: " << writeFileLocation + "lex" << endl;
            SyntaxAnalyzer analyzer;
            Lexer* lex = new Lexer();
            lex->OpenFileToLex(openFileLocation);
            analyzer.Parse(lex);
            analyzer.PrintResults(writeFileLocation + "syntax");
        }
        else
        {
            cout << "Error writing records to: " << writeFileLocation << endl;
        }
    }
    else // If the lexer had an error
    {
        if(lexer.WriteRecordsToFile(writeFileLocation))
        {
            cout << "Records written to: " << writeFileLocation << endl;
        }
        else
        {
            cout << "Error writing records to " << writeFileLocation << endl;
        }
        cout << "Error in parsing input file" << endl;
    }
    system("pause");// made a system call tsk tsk...
}

bool RunLexer(Lexer & lexer)
{
    bool isError = false;
    while(!lexer.isEndOfFile())
    {
        Record record = lexer.Lex();
        if(record.isError())
        {
            isError = true;
        }
        cout << record.ToString() << endl;
    } // continue loop
    return isError;
}